import React from 'react';
import ReactDOM from 'react-dom';
import store from './store';

document.addEventListener("DOMContentLoaded", () => {
 

    ReactDOM.render(< store/>, document.getElementById('root'));
});