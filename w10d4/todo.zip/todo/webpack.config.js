var path = require('path');

module.exports = {
    entry: "./frontend/entry.jsx",
    output: {
        path: path.resolve(__dirname),
        // path: path.resolve(__dirname, 'app', 'assets', 'javascripts'),
        // For Rails projects, make sure to locate your bundle.js file in app / assets / javascripts
        filename: "bundle.js"
    },
    module: {
        rules: [
            {
                test: [/\.jsx?$/],
                exclude: /(node_modules)/,
                use: {
                    loader: 'babel-loader',
                    query: {
                        presets: ['@babel/env', '@babel/react']
                    }
                },
            }
        ]
    },
    devtool: 'source-map',
    resolve: {
        extensions: [".js", ".jsx", "*"]
    }
};