class UsersController < ApplicationController

    def index 
        render json: User.all
    end

    def create

        #TODO implement user_params method
        user = User.new(user_params)
        if user.save
            render json: user
        else 
            render json: user.errors.full_messages, status: :unprocessable_entity
        end
      end
       

    def show 
        render json: User.find_by(user_params[:id])
    end

    private
    def user_params
        params
          .require(:user) # takes name of key in params as arg, requires everything to be nested under this key
          .permit(:name, :email, :age, :id) # 1 or more symbols corresponding to fields we want user to be able to set (everything else is filtered out / ignored)
    end
end

=begin

Three ways to pass params in an HTTP request as follows:

Using wildcards inside a route (e.g. /users/:id)
Via the query string (e.g. /path?param1=value1&param2=value2)
Inside the request body (usually built using a form, basically a bunch of key value pairs)
Should avoid for GET requests

=end