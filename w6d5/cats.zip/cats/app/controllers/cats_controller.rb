class CatsController < ApplicationController
    def index
        @cats = Cat.all 
        render :index
    end

    def show
        # @name = Cat.new(cats_params)

        # if @name.save!
            render json: params 
        # else
        #     render json: @name.errors.full_message, status: :unprocessable_entity
        # end
        
    end

    private

    def cats_params
        params.require(:cat).permit(
            :name, 
            :birth_date, 
            :color, 
            :sex, 
            :description)
    end
end