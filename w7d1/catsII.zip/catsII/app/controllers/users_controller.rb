class UsersController < ApplicationController
    
    before_action :redirect_to_cats_if_logged_in, only: [:new, :create]
    #the redirect runs before any of the controller actions methods
    #if you use only[:action_name] the before_action will only apply to the methods in the []

    def new
        render :new 
    end

    def create 
        @user = User.create(users_params)
        if @user.save
            login!(@user)               #logins user if their signup is sucessful
            redirect_to cats_url
        else
            flash.now[:errors] = @user.errors.full_messages
            render :new
        end
    end

    def users_params 
        params 
        .require(:user)
        .permit(:username, :password)
    end

end