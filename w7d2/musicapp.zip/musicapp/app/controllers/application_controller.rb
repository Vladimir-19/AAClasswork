class ApplicationController < ActionController::Base

    helper_method :current_user, :logged_in

    def current_user #to return the current user.
        return nil unless session[:session_token]
        @current_user ||= User.find_by(session_token: session[:session_token])
    end

    def logged_in? 
    #to return a boolean indicating whether someone is signed in.
        !!current_user
    end

    def login_user!(user)
    #reset the user's session token and cookie
        session[:session_token] = user.reset_session_token!
    end

    # def loguot!
    #     current_user.reset_session_token!
    #     @current_user = nil
    #     session[:session_token] = nil
    # end
end
