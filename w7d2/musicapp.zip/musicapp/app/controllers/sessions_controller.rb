class SessionController < ApplicationController
   
    def new
    render :new
   end

   def create #####??????
    #re-set the appropriate user's session_token and 
    # session[:session_token]
    user = User.find_by(
        params[:email][:email],
        params[:email][:password]) #password or password_digest
        if user.nil?
            flash.now[:errors] = ["Invalid credentials! From session controller"]
            render :new
        elsif !user.activated? #email verif.
            flash.now[:errors] = ['Activate account first! Check your email. (From session controller)']
            render :new
        else 
            login_user!(user) 
            redirect_to user_url # (show page)
        end
   end

   def destroy
    current_user.reset_session_token!
    session[:session_token] = nil
    @current_user = nil
    redirect_to new_session_url
   end

end